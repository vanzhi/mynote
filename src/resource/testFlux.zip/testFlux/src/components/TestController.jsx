import React from 'react';
import TestStore from '../stores/TestStore';
import TestActions from '../actions/TestActions';
import Test from './Test.jsx';
import Test2 from './Test2.jsx';
class TestController extends React.Component{
  constructor(props){
    super(props);    
    this.state={
      items: TestStore.getAll(),
      TestMsg:""
    };
  };

  componentDidMount() {
    TestStore.addGetMsgListener(this._getMsg.bind(this));
    TestStore.addChangeListener(this._onChange.bind(this));
  };

  componentWillUnmount() {
    TestStore.removeGetMsgListener(this._getMsg.bind(this));
    TestStore.removeChangeListener(this._onChange.bind(this));
  };

  _onChange() {
    this.setState({
      items: TestStore.getAll()
    });
  };

  _getMsg(){
    this.setState({
      TestMsg:TestStore.getMsg()
    })
  };

  createNewItem (event) {
    TestActions.addNewItem('new item !!!');    
  };

  getMsg(){
    TestActions.getMsg();
  }

  render() {
    return (
      <div>
        <p>react flux demo</p>
        { /* <Test items={this.state.items} onClick={(event)=>this.createNewItem(event)} /> */ }        
        <Test2 msg={this.state.TestMsg} onClick={(event)=>this.getMsg(event)} />
      </div>
    );
  };

};

module.exports = TestController;
