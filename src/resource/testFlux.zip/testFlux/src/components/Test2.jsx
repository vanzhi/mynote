import React from 'react';

var Test2 = function(props) {
  var msg = props.msg;  
  return (<div>
            <button onClick={props.onClick}>Get Msg</button>
            <div>{msg}</div>
        </div>);
};

module.exports = Test2;
