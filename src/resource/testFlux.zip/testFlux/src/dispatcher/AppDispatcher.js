import Flux from 'flux';
let Dispatcher=Flux.Dispatcher;
let AppDispatcher =new Dispatcher();
import TestStore from '../stores/TestStore';
import ActionTypes from "../constants/ActionTypeConstants";

AppDispatcher.register(function (action) {
  switch(action.actionType) {

    case ActionTypes.GET_MSG:
      //waitfor
      
      TestStore.getMsgHandler(action.params);
      TestStore.emitGetMsg();
      break;

    case ActionTypes.ADD_NEW_ITEM:
      TestStore.addNewItemHandler(action.text);
      TestStore.emitChange();
      break;
    default:
      break;
      
  }
});

module.exports = AppDispatcher;
