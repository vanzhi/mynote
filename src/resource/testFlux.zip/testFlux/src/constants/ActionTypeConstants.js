

const ActionTypes = {  
  ADD_NEW_ITEM: 'ADD_NEW_ITEM',
  GET_MSG:"GET_MSG"
};

export default ActionTypes;