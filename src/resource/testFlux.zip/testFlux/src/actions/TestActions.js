import AppDispatcher from "../dispatcher/AppDispatcher";
import ActionTypes from "../constants/ActionTypeConstants";

var ButtonActions = {

  getMsg:function(){
    AppDispatcher.dispatch({
      actionType: ActionTypes.GET_MSG,
      params:{}
    });
  },

  addNewItem: function (text) {
    AppDispatcher.dispatch({
      actionType: ActionTypes.ADD_NEW_ITEM,
      text: text
    });
  },

};

module.exports = ButtonActions;
