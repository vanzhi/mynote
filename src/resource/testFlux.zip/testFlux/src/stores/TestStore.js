import Events from 'events';
let EventEmitter=Events.EventEmitter;
import assign from 'object-assign';

var ListStore = assign({}, EventEmitter.prototype, {
  items: [],
  msg:"",

  getAll: function () {
    return this.items;
  },
  
  getMsg:function(){
    return this.msg;
  },
  
  getMsgHandler:function(params){
    this.msg="this is test msg";
  },

  emitGetMsg: function () {
    this.emit('get_msg');
  },

  addGetMsgListener: function (callback) {
    this.on('get_msg', callback);
  },

  removeGetMsgListener: function (callback) {
    this.removeListener('get_msg', callback);
  },

  addNewItemHandler: function (text) {
    this.items.push(text);
  },

  emitChange: function () {
    this.emit('addItem');
  },

  addChangeListener: function(callback) {
    this.on('addItem', callback);
  },

  removeChangeListener: function(callback) {
    this.removeListener('addItem', callback);
  }
});

module.exports = ListStore;
