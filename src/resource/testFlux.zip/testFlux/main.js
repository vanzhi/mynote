
import React from 'react';
import ReactDOM from 'react-dom';
import MyButtonController from './src/components/TestController.jsx';
ReactDOM.render(
  <MyButtonController/>,
  document.getElementById('app')
);