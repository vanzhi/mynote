
import React from 'react';
import MainController from '../controllers/mainController';
import SubComponenet from './subComponent.jsx';

class MainComponets extends React.Component {
	constructor(props){
		super(props);
	};
	
	changeTxt(){
		var txt = document.getElementById("testTxt").value;
		MainController.emitEvent(txt);
	};

	render(){
		return(
			<div>
				<p>react events demo</p>
				<input type="text" onChange={(event)=>this.changeTxt(event)} id="testTxt"/>
				<SubComponenet />
			</div>
		)
	};
}

export default MainComponets;