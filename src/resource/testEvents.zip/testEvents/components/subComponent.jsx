
import React from 'react';
import MainController from '../controllers/mainController';

class SubComponent extends React.Component {
	constructor(props){
		super(props);
        this.state={
            text:""
        }
	};
    
    componentDidMount(){
		MainController.addChangeListener(this.testChangeHandler.bind(this));
	};

    componentWillUnmount(){
		MainController.removeChangeListener(this.testChangeHandler.bind(this));
	};

    testChangeHandler(text){
        this.setState({
            text:text
        });
    };

    render(){
        return (
            <div>                
                {this.state.text}
            </div>
        );
    };
};

export default SubComponent;