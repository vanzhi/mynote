
import React from 'react';
import ReactDOM from 'react-dom';
import MainComponets from './components/mainComponets.jsx';

ReactDOM.render(
  <MainComponets/>,
  document.getElementById('app')
);