import Events from 'events';
let EventEmitter=Events.EventEmitter;
import assign from 'object-assign';

var mainController = assign({}, EventEmitter.prototype, {
  items: [],

  getAll: function () {
    return this.items;
  },

  addNewItemHandler: function (text) {
    this.items.push(text);
  },

  emitEvent: function (text) {
    this.emit('testevent',text);
  },

  addChangeListener: function(callback) {
    this.on('testevent', callback);
  },

  removeChangeListener: function(callback) {
    this.removeListener('testevent', callback);
  }
});


module.exports = mainController;
